"""
This is lambda code used to run to delta lake spark code
"""
import sys
import time
import logging

import boto3

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    conn = boto3.client("emr")
    #ssm = boto3.client('ssm', region_name='eu-central-1')
    CODE_DIR = f"s3://vf-bdc-vb-euce1-dev-sagemaker-discovery/deltalake/"
    step_args = ["/usr/bin/spark-submit", "--master","yarn","--conf", "spark.sql.extensions=io.delta.sql.DeltaSparkSessionExtension", "--conf", "spark.sql.catalog.spark_catalog=org.apache.spark.sql.delta.catalog.DeltaCatalog",  "--conf", "spark.shuffle.service.enabled=true", "--conf", "spark.jars=s3://vf-bdc-vb-euce1-dev-submission/delta/delta-core_2.11-0.6.1.jar", CODE_DIR + "delta_lake_poc.py" ]

    response = conn.run_job_flow(
        Name= 'spark_job_cluster',
        LogUri= 's3://get-leap-172670341454-logs/elasticmapreduce/poc-deltalake-emr-Cluster/',
        ReleaseLabel= 'emr-5.21.0',
        Instances={
            'MasterInstanceType': 'c5.xlarge',
            'SlaveInstanceType': 'c5.xlarge',
            'InstanceCount': 3,
            'KeepJobFlowAliveWhenNoSteps': False,
            'TerminationProtected': True,
            'Ec2SubnetId': 'subnet-03d7856d38409f38a'
        },
        Applications = [ {'Name': 'Spark'} ],
        Configurations = [ 
            { 'Classification': 'spark-hive-site',
              'Properties': { 
                  'hive.metastore.client.factory.class': 'com.amazonaws.glue.catalog.metastore.AWSGlueDataCatalogHiveClientFactory'}
            }
        ],
        VisibleToAllUsers=True,
        JobFlowRole = 'SC-172670341454-pp-wmxztnmwvlzfi-EMRStack-Q8WC5MF1NRK2-EMREC2InstanceProfile-6N82RLGYXPBD',
        ServiceRole = 'poc-deltalake-emr-EMRServiceRole',
        Steps=[
            {
                'Name': 'flow-log-analysis',
                'ActionOnFailure': 'TERMINATE_CLUSTER',
                'HadoopJarStep': {
                        'Jar': 'command-runner.jar',
                        'Args': step_args
                }
            }
        ],
        BootstrapActions=[
            {
                'Name': 'delta_lake_bootstraping',
                'ScriptBootstrapAction': {
                    'Path': 's3://vf-bdc-vb-euce1-dev-submission/delta/delta_lake_bootstrap.sh',
                    'Args': ['test']
                }
            }
        ]

    )    






#    CODE_DIR = f"s3://vf-bdc-vb-euce1-dev-sagemaker-discovery/deltalake/"

    # spark configuration example
    #step_args = ["/usr/bin/spark-submit", "--conf","spark.sql.extensions=io.delta.sql.DeltaSparkSessionExtension","--conf","spark.sql.catalog.spark_catalog=org.apache.spark.sql.delta.catalog.DeltaCatalog",  "--packages", "io.delta:delta-core_2.11:0.6.1",
    #               "--conf", "spark.shuffle.service.enabled=true",CODE_DIR + "delta_lake_poc.py","--conf","spark.sql.extensions=io.delta.sql.DeltaSparkSessionExtension", "--conf","spark.sql.catalog.spark_catalog=org.apache.spark.sql.delta.catalog.DeltaCatalog",
    #                  "JAR", "spark.jars=s3://vf-bdc-vb-euce1-dev-submission/delta/delta-core_2.11-0.6.1.jar" ]

   # step_args = ["/usr/bin/spark-submit", "--master","yarn","--conf", "spark.sql.extensions=io.delta.sql.DeltaSparkSessionExtension", "--conf", "spark.sql.catalog.spark_catalog=org.apache.spark.sql.delta.catalog.DeltaCatalog",  "--conf", "spark.shuffle.service.enabled=true", "--conf", "spark.jars=s3://vf-bdc-vb-euce1-dev-submission/delta/delta-core_2.11-0.6.1.jar", CODE_DIR + "delta_lake_poc.py" ]

    #name = f'deltalake-PoC'

#    step = {"Name": name,
#            'ActionOnFailure': 'CONTINUE',
#            'HadoopJarStep': {
#                'Jar': 's3n://eu-central-1.elasticmapreduce/libs/script-runner/script-runner.jar',
#                'Args': step_args
#            }
#        }
#    action = conn.add_job_flow_steps(JobFlowId='j-1TXKR1W6BZCUT', Steps=[step])
#    return "Added step: %s"%(action)