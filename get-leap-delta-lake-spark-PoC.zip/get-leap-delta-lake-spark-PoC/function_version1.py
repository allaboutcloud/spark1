"""
This is lambda code used to run to delta lake spark code
"""
import sys
import time
import logging

import boto3

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    conn = boto3.client("emr")
    ssm = boto3.client('ssm', region_name='eu-central-1')
    #ENV = ssm.get_parameters(Names=['TARIFF_ENV'], WithDecryption=True)["Parameters"][0]["Value"]
    # chooses the first cluster which is Running or Waiting
    # possibly can also choose by name or already have the cluster id
    #clusters = conn.list_clusters(ClusterStates=['RUNNING', 'WAITING'])
    #logger.info(f"CLUSTERS: {clusters}")

    # choose cluster (if vcity_ds cluster is available go on. If not, choose get-leap cluster)
    #cls_ids = [c["Id"] for c in clusters["Clusters"]]
    #cls_names = [c["Name"] for c in clusters["Clusters"]]

   # cluster_name = 'vcity_ds_etl_processing-EMR-Cluster' if 'vcity_ds_etl_processing-EMR-Cluster' in cls_names else 'get-leap-tarrif-matching-emr-EMR-Cluster'

    #try:
    #    cluster_id = cls_ids[cls_names.index(cluster_name)]
    #except:
    #    sys.stderr.write("No valid cluster. Please review your cluster configuration")
    #    sys.stderr.exit()

    # code location on your emr master node
    CODE_DIR = f"s3://vf-bdc-vb-euce1-dev-sagemaker-discovery/deltalake/"

    # spark configuration example
    #step_args = ["/usr/bin/spark-submit", "--conf","spark.sql.extensions=io.delta.sql.DeltaSparkSessionExtension","--conf","spark.sql.catalog.spark_catalog=org.apache.spark.sql.delta.catalog.DeltaCatalog",  "--packages", "io.delta:delta-core_2.11:0.6.1",
    #               "--conf", "spark.shuffle.service.enabled=true",CODE_DIR + "delta_lake_poc.py","--conf","spark.sql.extensions=io.delta.sql.DeltaSparkSessionExtension", "--conf","spark.sql.catalog.spark_catalog=org.apache.spark.sql.delta.catalog.DeltaCatalog",
    #                  "JAR", "spark.jars=s3://vf-bdc-vb-euce1-dev-submission/delta/delta-core_2.11-0.6.1.jar" ]

    step_args = ["/usr/bin/spark-submit", "--master","yarn","--conf", "spark.sql.extensions=io.delta.sql.DeltaSparkSessionExtension", "--conf", "spark.sql.catalog.spark_catalog=org.apache.spark.sql.delta.catalog.DeltaCatalog",  "--conf", "spark.shuffle.service.enabled=true", "--conf", "spark.jars=s3://vf-bdc-vb-euce1-dev-submission/delta/delta-core_2.11-0.6.1.jar", CODE_DIR + "delta_lake_poc.py" ]

    name = f'deltalake-PoC'

    step = {"Name": name,
            'ActionOnFailure': 'CONTINUE',
            'HadoopJarStep': {
                'Jar': 's3n://eu-central-1.elasticmapreduce/libs/script-runner/script-runner.jar',
                'Args': step_args
            }
        }
    action = conn.add_job_flow_steps(JobFlowId='j-2KOU7C3C9GR0O', Steps=[step])
    return "Added step: %s"%(action)